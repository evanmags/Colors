// variable definitions
    //element selectors
    var body = document.querySelector("body");
    var container = document.querySelector(".container");
    var generate = document.querySelector(".gen");
    var invert = document.querySelector(".inv");
    var previous = document.querySelector(".prev");
    var next = document.querySelector(".next");
    var selectCol = document.querySelector("select");
    var spanA = document.querySelector(".spanA");
    var spanB = document.querySelector(".spanB");
    var undo = document.querySelector("#undo");
    var icon = document.getElementsByClassName("tog");
    var toggle = document.getElementById("controlToggle");
    var controls = document.getElementById("controls");
    var colType = document.getElementById("colType");
    var converted = document.getElementById("converted1");

    // text value variables
    var aTextI = "The color you inverted to is: ";
    var aTextG = "The color you generated is: ";
    var bTextI = "The your original color is: ";
    var bTextG = "The inverse of your color is: ";
    var cTextI = "";
    var cTextG = "The color you created is: ";

    //manipulated variables
    var color;
    var inverse;
    var x;
    var z;
    var pre;
    var r;
    var g;
    var b;

    // array defined variables
    var hexList = ["0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"];
    var colorList = [];
    var pList = document.querySelectorAll(".primary");
    var sList = document.querySelectorAll(".secondary");
    var tiles = document.querySelectorAll(".tile");
    var labels = document.querySelectorAll("label");
        var s1l = labels[1];
        var s2l = labels[2];
        var s3l = labels[3];
    var sliders = document.querySelectorAll("input");
        var s1s = sliders[0];
        var s2s = sliders[1];
        var s3s = sliders[2];
    var slideDisp = document.querySelectorAll(".sDisp");
        var s1d = slideDisp[0];
        var s2d = slideDisp[1];
        var s3d = slideDisp[2];

// listener events for buttons, sliders and drop down
    // listeners for single target variables
    generate.addEventListener("click", colors);
    invert.addEventListener("click", inverseColors);
    previous.addEventListener("click", last);
    next.addEventListener("click", first);
    undo.addEventListener("click", init);
    toggle.addEventListener("click", showControls);
    selectCol.addEventListener("change", function(){
        colType.textContent = this.value;
        slideLabels(this);
        slideDisps();

    });
    
    // listeners for array stored (multi-target) variables
    for(x = 0; x < 5; x++){
        tiles[x].addEventListener("click", tileColor);
    };
    for(x = 0; x < 3; x++){
        sliders[x].addEventListener("mousemove", slideDisps);
    }

// Function definitions
    //Initiation function (also used on reset)
    function init(){
        colorList = [];
        colors();
        body.style.background = color;
        slideLabels(selectCol);
        for(t = 0; t < 5; t++){
            hide(tiles[t]);
        };
        hide(previous);
        x = true;
        z = 0;
        pre = 0;
        spanA.textContent = "Generate a color!";
        spanB.textContent = "";
    }

//Color generators (contain dependencies for this app)
    function hex6(){
        var hex = "#";
        var invHex = "#"; 
        for(i = 0; i < 6; i++){
            y = Math.floor(Math.random() * hexList.length); 
            hex = hex + hexList[y];
            invHex = invHex + hexList[(15-y)];
        }
        r = parseInt(hex[1]+hex[2], 16);
        g = parseInt(hex[3]+hex[4], 16);
        b = parseInt(hex[5]+hex[6], 16);
        colorList.push({col : hex, inverse : invHex});
        color = hex; 
        inverse = invHex;
        return color, inverse, r, g, b;
    }

//button functions, to trigger on user action
    //generate color function
    function colors(){
        pickColorType(selectCol.value);
        if(z > -1 && z < 5){reveal(tiles[z]);}
        tileShift();
        hide(next);
        reveal(previous);
        slideValues(r, g, b);
        slideDisps();
        Display(aTextG, bTextG, color, inverse);
        converted.textContent = String("rgb("+r+", "+g+", "+b+")");
        return color, inverse, x= true, z++, pre = 0;
    }

    //inverse function
    function inverseColors(){
        if(x){
            Display(aTextI, bTextI, inverse, color);
            return x = false;
        }
        else{
            Display(aTextI, bTextI, color, inverse);
            return x = true;
        }
    }

    //previous and next control functions
    function shift(){
        color = colorList[z-pre].col;
        inverse = colorList[z-pre].inverse;
        Display(aTextG, bTextG, color, inverse);
        if(pre === 0){
            hide(next);
        }
        if(pre === colorList.length-1){
            hide(previous);
        }
        return pre, x = true;
    }

    function first(){
        if(pre >-1){
            pre--;
            reveal(previous);
            shift();
        }
    }

    function last(){
        if(pre < colorList.length){
            pre++;
            reveal(next);
            shift();
        }
    }

    //tile display functions
    function tileColor(){
        color = colorList[z-1].col;
        inverse = colorList[z-1].inverse;
        Display(aTextG, bTextG, color, inverse);
        return x = true;
    }

    function tileShift(){
        var index = 0;
        for(t = colorList.length-2; t > colorList.length-7; t--){
            if(t >= 0){
            pList[index].style.backgroundColor = colorList[t].col;
            sList[index].style.backgroundColor = colorList[t].inverse;
            index++;
            }
        }
    }

    function Display(a, b, c, i){
        spanA.textContent = a + c;
        spanB.textContent = b + i;
        body.style.background = c;
        spanB.style.color = i;
    }

    function slideLabels(x){
        if(selectCol.value === "hsl" || selectCol.value === "hsla"){
            s1l.textContent = "Hue:";
            s2l.textContent = "Saturation:";
            s3l.textContent = "Lightness:";
        }
        else{
            s1l.textContent = "Red:";
            s2l.textContent = "Green:";
            s3l.textContent = "Blue:";
        }
    }

    //text display functions
    function slideDisps(){
        if(selectCol.value === "hex6"){
            rd = parseInt(s1s.value, 10);
            gd = parseInt(s2s.value, 10);
            bd = parseInt(s3s.value, 10);

            rd = rd.toString(16);
            gd = gd.toString(16);
            bd = bd.toString(16);

            if(!rd[1]){
                rd = "0" + rd;
            }
            if(!gd[1]){
                gd = "0" + gd;
            }
            if(!bd[1]){
                bd = "0" + bd;
            }

            s1d.textContent = rd;
            s2d.textContent = gd;
            s3d.textContent = bd;
        }
        else{
            s1d.textContent = s1s.value;
            s2d.textContent = s2s.value;
            s3d.textContent = s3s.value;
        }
        color = "#"+rd+gd+bd;
        Display(cTextG, cTextI, color, cTextI)
    }

function slideValues(r, g, b){
    s1s.value = r;
    s2s.value = g;
    s3s.value = b;
}
function hide(x){
    x.classList.add("hide");
}

function reveal(x){
    x.classList.remove("hide");
}

function pickColorType(x){
    if(x === "hex6"){hex6();}
    else if(x === "hex3"){hex3();}
    else if(x === "rgb"){rgb();}
    else if(x === "rgba"){rgba();}
    else if(x === "hsl"){hsl();}
    else if(x === "hsla"){hsla();}
}

function showControls(){
    container.classList.toggle("large");
    controls.classList.toggle("hidden");
    icon[0].classList.toggle("hide");
    icon[1].classList.toggle("hide");
}

//functions to run on load, without user interaction
init();