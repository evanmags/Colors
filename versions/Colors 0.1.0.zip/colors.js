// variable definitions
var generate = document.querySelector(".gen");
var invert = document.querySelector(".inv");
var previous = document.querySelector(".prev");
var next = document.querySelector(".next");
var body = document.querySelector("body");
var spanA = document.querySelector(".spanA");
var spanB = document.querySelector(".spanB");
var color = "";
var inverse = "";
var x = true;
var z = 0;
var pre = 1;

// array definitions
var hexList = ["0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"];
var colorList = [];
var pList = document.querySelectorAll(".primary");
var sList = document.querySelectorAll(".secondary");
var tiles = document.querySelectorAll(".tile");

// listener events
generate.addEventListener("click", colors);
invert.addEventListener("click", inverseColors);
previous.addEventListener("click", last);
next.addEventListener("click", first);
for(x = 0; x < 5; x++){
    tiles[x].addEventListener("click", tileColor);
};

function colors(){
    var hex = "#";
    var invHex = "#"; 
    for(i = 0; i < 6; i++){
        y = Math.floor(Math.random() * hexList.length); 
        hex = String(hex + hexList[y]);
        invHex = String(invHex + hexList[(15-y)])
    }
    colorList.push({col : hex, inverse : invHex});
    color = hex; 
    inverse = invHex;
    setDisplay();
    if(z > 0 && z < 6){
        reveal(tiles[z-1]);
        reveal(previous);
    }
    tileShift();
    hide(next);
    return color, inverse, x= true, z++, pre = 1;
}

function inverseColors(){
    if(x){
        swap(inverse, color);
        return x = false;
    }
    else{
        swap(color, inverse);
        return x = true;
    }
}

function tileColor(){
    color = colorList[z-2].col;
    inverse = colorList[z-2].inverse;
    setDisplay();
    return x = true;
}

function last(){
    if(pre < colorList.length){
        pre += 1;
        reveal(next);
        shift();
    }
}

function first(){
    if(pre > 1){
        pre -= 1;
        reveal(previous);
        shift();
    }
}

function tileShift(){
    if(z > 0){
        ind = 0;
        pList.forEach(function(){
            q = (z-1)-ind;
            if(ind >= 0 && q >= 0){
                pList[ind].style.backgroundColor = colorList[q].col;
                sList[ind].style.backgroundColor = colorList[q].inverse;
                ind++;
            }
        })
    }
}

function shift(){
    color = colorList[z-pre].col;
    inverse = colorList[z-pre].inverse;
    setDisplay();
    if(pre === 1){
        hide(next);
    }
    if(pre === colorList.length){
        hide(previous);
    }
    return pre, x = true;
}

function swap(g, h){
    spanA.textContent = "The color you inverted to is: " + g;
    spanB.textContent = "The your original color is: " + h;
    body.style.background = g;
    spanB.style.color = h;
}

function setDisplay(){
    body.style.background = color;
    spanB.style.color = inverse;
    spanA.textContent = "The color you generated is: " + color;
    spanB.textContent = "The inverse of your color is: " + inverse;
}

function hide(x){
    x.style.display = "none";
}

function reveal(x){
    x.style.display = "inline";
}