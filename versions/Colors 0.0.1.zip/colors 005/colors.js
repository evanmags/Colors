// variable definitions
var generate = document.querySelector(".gen");
var invert = document.querySelector(".inv");
var body = document.querySelector("body");
var spanA = document.querySelector(".spanA");
var spanB = document.querySelector(".spanB");
var color = "";
var inverse = "";
var x = null;

// listener events
generate.addEventListener("click", colors);
invert.addEventListener("click", inverseColors);

// generate color function
function colors(){
    
    // required variables for hex colors
    var colors = ["0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"];
    var hex = "#";
    var invHex = "#";
    
    // for loop generates 2, 6-charictor strings prepended by # from colors array (hex & invHex)
    for(i = 0; i < 6; i++){
        y = Math.floor(Math.random() * colors.length); 
        hex = String(hex + colors[y]);
        invHex = String(invHex + colors[(15-y)])
    }
    // sets background, generates text, and sets span colors
    body.style.background = hex;
    spanA.textContent = "The color you generated is: " + hex;
    spanB.textContent = "The inverse of your color is: " + invHex;
    spanB.style.color = invHex;
    
    // returns local variables to global holders, resets inverseColors function
    return  color = hex, inverse = invHex, x= true;
}

// inverse colors function; see output of colors() for explainations.
function inverseColors(){
    if(x){
        body.style.background = inverse;
        spanA.textContent = "The color you inverted to is: " + inverse;
        spanB.textContent = "The your original color is: " + color;
        spanB.style.color = color;
        return x = false;
    }
    else{
        body.style.background = color;
        spanA.textContent = "The color you inverted to is: " + color;
        spanB.textContent = "The your original color is: " + inverse;
        spanB.style.color = inverse;
        return x = true;
    }

}